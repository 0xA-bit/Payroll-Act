<?php 
include "Srv.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employees Payroll</title>
</head>
    <body>
        <div class="container">
            <form method="POST" action="output.php">

                Please enter your ID:
                    <INPUT type="text" name="empID" required>
                    <br>
                Please enter your name: 
                    <INPUT type="text" name="empName" required>
                    <br>
                Daily Wage: 
                    <INPUT type="text" name="empWage" required>
                    <br>
                No. of Days:
                    <INPUT type="text" name="empDays" required>
                    <br>
                This month's pay:
                    <INPUT type="text" name="empPay" required>
                    <br>        
                    <button type="submit" name="Save_items">Submit</button>
            </div>
        </form>
    </body>
</html>




       

        

        

