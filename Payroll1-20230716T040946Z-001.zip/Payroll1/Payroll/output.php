<?php
include "Srv.php";


if(isset($_POST['Save_items'])) {


$eID = $_POST["empID"];
$eName = $_POST["empName"];
$eWage = $_POST["empWage"];
$eDays = $_POST["empDays"];
$ePay = $_POST["empPay"];

echo "<font color=green>Emp ID:</font><br>" . $eID . "<br>";

echo "<font color=green>Emp Name:</font><br> " . $eName . "<br>";

echo "<font color=green>Daily Wage:</font><br>" . "₱" . $eWage . "<br>";

echo "<font color=green>No. of Days</font><br>" . $eDays . "days" . "<br>";

$MontlyPay = $eWage * 25;
echo "<font color=green>This Month's Pay:</font><br>" . "₱" . $MontlyPay . "<br>";

$_13Month = $MontlyPay / 12 * 11;
echo "<font color=green>13th Month Pay:</font><br>" . "₱" . $_13Month . "<br>";

$Deductions = $ePay * 0.15;
echo "<font color=green>Deduction:</font><br>" . "₱" . $Deductions . "<br>";

$FinalPay = $ePay + $_13Month - $Deductions;
echo "<font color=green>Final pay:</font><br>" . "₱" . $FinalPay;   

    $SqlQuery = "INSERT INTO `db_tbl`(`id`, `Emp_name`, `Daily_wage`, `No_of_days`, `This_month_pay`, `13th_month`, `Deduction`, `Final_pay`) 
                 VALUES ('$eID','$eName','$eWage','$eDays','$ePay','$_13Month','$Deductions','$FinalPay')";
 
    $result = mysqli_query($conn, $SqlQuery);   
}
?>