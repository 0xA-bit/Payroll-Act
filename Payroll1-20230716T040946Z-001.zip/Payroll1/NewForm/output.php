<?php
include "Server.php";


if(isset($_POST['Save_items'])) {


$eID = $_POST["empID"];
$eName = $_POST["empName"];
$eWage = $_POST["empWage"];
$eDays = $_POST["empDays"];
$eRendered = $_POST["empMosRendered"];


echo "<font color=red><br>Employee ID: <br></font>" . $eID . "<br>";
echo "<font color=red><br>Employee Name: <br></font>" . $eName . "<br>";
echo "<font color=red><br>Daily Wage: <br></font>" . "<font color=green>₱</font>". $eWage . "<br>";
echo "<font color=red><br>Total No. of Days: <br></font>" . $eDays . "<br>";
echo "<font color=red><br>Months Rendered: <br></font>" . $eRendered . "<br>";

$GrossPay = $eWage * $eDays;
echo "<font color=red><br>This Month's Pay: <br></font>" . "<font color=green>₱</font>" . $GrossPay . "<br>";

$_13Month = $GrossPay / 12 * $eRendered;
echo "<font color=red><br>13th Month Pay: <br></font>" . "<font color=green>₱</font>" . $_13Month . "<br>";

$Deductions = $GrossPay * 0.15;
echo "<font color=red><br>Deductions: <br></font>" . "<font color=green>₱</font>" . $Deductions . "<br><br>";

$BonusPay = $GrossPay * 0.15 + $_13Month * 0.50;
echo "Bonus pay: <br>" . $BonusPay . "<br>";

$FinalPay = $GrossPay + $_13Month + $BonusPay - $Deductions;
echo "<font color=red><br>Final Pay: <br></font>" . "<font color=green>₱</font>" . $FinalPay . "<br>";
 

$Sql = "INSERT INTO `db_tbl`(`id`, `Emp_name`, `Daily_wage`, `No_of_days`, `This_month_pay`, `13th_month`, `Bonus_Pay`, `Deduction`, `Final_pay`) 
                    VALUES ('$eID','$eName','$eWage','$eDays','$GrossPay','$_13Month','$Deductions', $BonusPay,'$FinalPay')";

$result = mysqli_query($conn, $Sql);  

}
?>