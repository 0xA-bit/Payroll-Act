<?php

$mar10srv = "localhost";
$username = "root";
$password = "";
$db = "new_db_crud";

$conn = new mysqli($mar10srv, $username, $password, $db);

if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>