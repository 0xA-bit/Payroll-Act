<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="output.php" method="POST">    
        Please enter your ID:
                <INPUT type="text" name="empID">
                <br>
        Please enter your name: 
                <INPUT type="text" name="empName">
                <br>
        Daily Wage: 
                <INPUT type="text" name="empWage">
                <br>
        No. of Days:
            <INPUT type="text" name="empDays">
                <br>
        Months Rendered:
            <input type="text" name="empMosRendered">
        <br>
        <button type="submit" name="Save_items">Submit</button>
    </form>
</body>
</html>